# SEDB v0.2A — AI-Native Unbounded Dynamic Field Database

**Semantic Evolution Database / Unbounded Dynamic Field Layer / Field Governance Kernel**

SEDB is a local-first experimental database for AI-native research, classification, curation, and record keeping where the logical field space may grow from hundreds to thousands or tens of thousands of fields without requiring every record to materialize every field.

The original v0.1 rule remains:

$$
\boxed{\text{Add Field}\not\Rightarrow\text{Fill Field}}
$$

v0.2A adds the governance rule:

$$
\boxed{\text{Unbounded Field Growth}\neq\text{Ungoverned Canonical Growth}}
$$

A field may exist globally while most records remain blank. A new proposal may also be accepted without creating a new canonical field when deterministic normalization shows that an equivalent canonical identity already exists.

## Core model

Let $E$ be records, $F$ the open-ended field registry, and $D_f$ the value domain of field $f$:

$$
V:E\times F\rightarrow D_f\cup\{\varnothing\}.
$$

Only present cells are physically stored:

$$
C=\{(e,f,v)\mid V(e,f)\neq\varnothing\}.
$$

For a task $Q$, only a local field support must be projected:

$$
F_Q\subseteq F.
$$

## v0.2A highlights

- dynamic field registry without `ALTER TABLE ADD COLUMN` per discovered field;
- sparse JSON-valued cells and true blank-by-absence semantics;
- 10,000+ logical field operation;
- field lifecycle and convergence/reactivation evaluations;
- deterministic normalized identity check;
- namespace metadata;
- aliases that resolve to one canonical field;
- proposal queue with accept/reject decisions;
- duplicate proposal acceptance as alias instead of duplicate canonical field;
- immutable field definition versions;
- explicit merge/split lineage;
- lineage-free direct merge/split transitions blocked;
- Task Views and bounded field-window matrix rendering;
- field/entity/cell search;
- CSV/JSONL exchange;
- local JSON HTTP API;
- browser UI with minimal Field Governance panel;
- automatic v0.1 SQLite forward migration;
- no runtime third-party dependencies.

## Deterministic field identity

v0.2A uses a deliberately conservative model-free normalizer:

```text
Unicode NFKC
→ trim
→ lower-case
→ whitespace/hyphen/dot/slash → _
→ collapse repeated _
```

For example:

```text
Author-Country
AUTHOR / COUNTRY
author country
```

all normalize to:

```text
author_country
```

If a proposal normalizes to an existing canonical field in the same namespace, accepting it records an alias and proposal decision targeting the existing field. It does **not** create a second canonical field.

This is deterministic identity governance, not semantic AI deduplication. Embedding/LLM similarity remains deferred.

## Field definition versions

Every canonical field has immutable version history. Current field metadata may change, but older versions are never rewritten.

A definition update requires a reason and appends:

$$
v_1\rightarrow v_2\rightarrow\cdots\rightarrow v_n.
$$

Existing v0.1 fields receive a version-1 migration snapshot automatically.

## Merge / split lineage

Merge and split are explicit governance operations:

```text
source --merged_into--> target
source --split_into----> child A
source --split_into----> child B
```

They update field lifecycle state and write lineage edges. They **do not** silently copy, move, or delete sparse cells.

## Storage model

Core and governance structures include:

```text
entities
fields
cells
field_events
field_evaluations
field_proposals
proposal_decisions
field_aliases
field_versions
field_lineage
task_views
task_view_fields
```

## Requirements

- Python 3.11+;
- SQLite included with Python;
- no runtime third-party dependencies;
- `pytest` only for tests.

## Windows PowerShell quick start

```powershell
cd SEDB-v0.2A-local
python -m pip install -e .
sedb demo --db .\sedb-demo.sqlite --fields 10000
sedb serve --db .\sedb-demo.sqlite --host 127.0.0.1 --port 8765
```

Open:

```text
http://127.0.0.1:8765
```

Without editable install:

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m sedb.cli demo --db .\sedb-demo.sqlite --fields 10000
python -m sedb.cli serve --db .\sedb-demo.sqlite
```

## Python governance example

```python
from sedb.db import Database
from sedb.fields import FieldService
from sedb.governance import FieldGovernanceService


db = Database("research.sqlite")
fields = FieldService(db)
governance = FieldGovernanceService(db)

canonical = fields.create_field(
    key="author_country",
    label="Author country",
)

proposal = fields.create_proposal(
    key="Author-Country",
    label="Imported author country",
    reason="Imported schema vocabulary",
    proposed_by="agent:importer",
)

decision = governance.decide_proposal(
    proposal["id"],
    "accept",
    reason="Same deterministic identity",
    evaluator="reviewer:local",
)

assert decision["outcome"] == "alias_existing"
assert decision["target_field_id"] == canonical["id"]
```

## Local API

Important routes:

```text
GET    /api/health
GET    /api/stats
GET    /api/fields
POST   /api/fields
POST   /api/fields/{id}/transition
GET    /api/fields/{id}/evaluations
POST   /api/fields/{id}/aliases
GET    /api/fields/{id}/aliases
POST   /api/fields/{id}/definition
GET    /api/fields/{id}/versions
GET    /api/fields/{id}/lineage
GET    /api/proposals
POST   /api/proposals
POST   /api/proposals/{id}/decision
GET    /api/proposals/{id}/decision
POST   /api/governance/merge
POST   /api/governance/split
GET    /api/entities
POST   /api/entities
GET    /api/entities/{id}
PUT    /api/entities/{id}/cells/{field_key}
DELETE /api/entities/{id}/cells/{field_key}
GET    /api/search?q=...
GET    /api/views
POST   /api/views
GET    /api/views/{id}?field_offset=0&field_limit=25
```

To restore blank, use `DELETE`; do not write a fake placeholder.

## Automatic migration

Opening a v0.1 SQLite database with v0.2A automatically:

- adds governance metadata columns;
- creates governance tables;
- backfills deterministic normalized keys;
- creates version-1 snapshots for legacy fields;
- preserves existing field/entity/cell IDs and data.

No destructive table rebuild is used in v0.2A migration.

## Test

```bash
PYTHONPATH=src pytest -q
python -m compileall -q src examples
node --check src/sedb/web/app.js
```

## Project status

This artifact is the **local v0.2A checkpoint**. GitHub is intentionally not updated during local-first development.

$$
\boxed{
\text{Local Development}
\rightarrow
\text{Validation}
\rightarrow
\text{Stable Snapshot}
\rightarrow
\text{Selective GitHub Sync}
}
$$

## Licensing status

No public software license is selected by this local v0.2A artifact. Do not infer an open-source license from the existence of the source bundle or public repository.

## Design / release documents

- `docs/superpowers/specs/2026-08-20-sedb-unbounded-field-v0.1-design.md`
- `docs/superpowers/plans/2026-08-20-sedb-unbounded-field-v0.1.md`
- `docs/RELEASE_NOTES_v0.1.md`
- `docs/superpowers/specs/2026-08-20-field-governance-kernel-design.md`
- `docs/superpowers/plans/2026-08-20-field-governance-kernel.md`
- `docs/RELEASE_NOTES_v0.2A.md`
