# SEDB v0.2A Demo Databases

## `sedb-demo-10k-v0.2a.sqlite`

A fresh v0.2A sparse-width checkpoint containing 10,000 canonical logical fields, three demo entities, sparse cells, one Task View, and immutable version-1 rows for the field registry.

See `stats-v0.2a.json` for its summary.

## `sedb-governance-v0.2a.sqlite`

A small governance fixture that intentionally contains:

- a normalized duplicate proposal accepted as `alias_existing`;
- one alias pointing to a canonical field;
- one field definition updated to version 2;
- one `merged_into` lineage edge;
- two `split_into` lineage edges;
- a sparse cell kept on the merged source to demonstrate that merge does not silently migrate data.

See `governance-stats-v0.2a.json` for its summary.
