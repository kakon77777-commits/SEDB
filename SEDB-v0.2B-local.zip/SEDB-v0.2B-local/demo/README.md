# SEDB v0.2B Demo Databases

## `sedb-demo-10k-v0.2b.sqlite`

Fresh sparse-width demo with 10,000 canonical logical fields, three entities, nine sparse cells, one Task View, and 10,000 immutable version-1 field snapshots. See `stats-v0.2b.json`.

## `sedb-semantic-scan-10k-v0.2b.sqlite`

Fresh 10,000-field registry used for bounded semantic-candidate scan validation. It contains two intentionally reordered duplicate pairs. The scan uses `max_neighbors=6`, `threshold=0.95`, and persists only candidates above threshold. See `semantic-scan-stats-v0.2b.json` for the concrete local run.

The runtime value is environment-specific evidence only. The structural comparison is between 49,995,000 naive unordered all-pairs at 10K fields and a configured candidate upper bound of 60,000 before threshold filtering.

## `sedb-governance-v0.2b.sqlite`

Small governance fixture containing deterministic normalized aliasing, semantic proposal alias review, immutable definition versions, canonical `related_to`, merge/split lineage, and a sparse cell deliberately retained on a merged source. One related pair is reviewed before a later definition-version change, demonstrating that semantic review history is not silently rewritten by current metadata. See `governance-stats-v0.2b.json`.
