"""SEDB local-first unbounded dynamic field database."""

__version__ = "0.2.0b1"
