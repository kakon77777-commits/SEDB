from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .naming import normalize_field_key


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'record',
    label TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fields (
    id TEXT PRIMARY KEY,
    key TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL,
    value_type TEXT NOT NULL DEFAULT 'text',
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active'
        CHECK(status IN ('proposed','active','converged','merged','split','deprecated')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'global',
    normalized_key TEXT
);

CREATE TABLE IF NOT EXISTS cells (
    entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    value_json TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT '',
    confidence REAL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(entity_id, field_id)
);

CREATE INDEX IF NOT EXISTS idx_cells_field_id ON cells(field_id);

CREATE TABLE IF NOT EXISTS field_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    reason TEXT NOT NULL DEFAULT '',
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS field_evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    decision TEXT NOT NULL,
    reason TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    metrics_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    reversible INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS field_proposals (
    id TEXT PRIMARY KEY,
    key TEXT NOT NULL,
    label TEXT NOT NULL,
    value_type TEXT NOT NULL DEFAULT 'text',
    description TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL,
    proposed_by TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending','accepted','rejected')),
    created_at TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'global'
);

CREATE TABLE IF NOT EXISTS task_views (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    query_text TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS task_view_fields (
    view_id TEXT NOT NULL REFERENCES task_views(id) ON DELETE CASCADE,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL,
    PRIMARY KEY(view_id, field_id),
    UNIQUE(view_id, ordinal)
);
"""


GOVERNANCE_SCHEMA = """
CREATE TABLE IF NOT EXISTS field_aliases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace TEXT NOT NULL DEFAULT 'global',
    alias TEXT NOT NULL,
    normalized_alias TEXT NOT NULL,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(namespace, normalized_alias)
);

CREATE INDEX IF NOT EXISTS idx_field_aliases_field_id ON field_aliases(field_id);
CREATE INDEX IF NOT EXISTS idx_fields_namespace_normalized ON fields(namespace, normalized_key);

CREATE TABLE IF NOT EXISTS field_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    label TEXT NOT NULL,
    value_type TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL,
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(field_id, version)
);

CREATE TABLE IF NOT EXISTS field_lineage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    child_field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    relation TEXT NOT NULL CHECK(relation IN ('merged_into','split_into')),
    reason TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(parent_field_id, child_field_id, relation)
);

CREATE INDEX IF NOT EXISTS idx_field_lineage_parent ON field_lineage(parent_field_id);
CREATE INDEX IF NOT EXISTS idx_field_lineage_child ON field_lineage(child_field_id);

CREATE TABLE IF NOT EXISTS proposal_decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id TEXT NOT NULL UNIQUE REFERENCES field_proposals(id) ON DELETE CASCADE,
    decision TEXT NOT NULL CHECK(decision IN ('accepted','rejected')),
    outcome TEXT NOT NULL,
    target_field_id TEXT REFERENCES fields(id) ON DELETE SET NULL,
    reason TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
"""


SEMANTIC_SCHEMA = """
CREATE TABLE IF NOT EXISTS semantic_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace TEXT NOT NULL DEFAULT 'global',
    source_kind TEXT NOT NULL CHECK(source_kind IN ('proposal','field')),
    source_ref TEXT NOT NULL,
    candidate_field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    score REAL NOT NULL,
    signals_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','reviewed')),
    created_at TEXT NOT NULL,
    UNIQUE(source_kind, source_ref, candidate_field_id)
);

CREATE INDEX IF NOT EXISTS idx_semantic_candidates_source
ON semantic_candidates(source_kind, source_ref);
CREATE INDEX IF NOT EXISTS idx_semantic_candidates_status
ON semantic_candidates(status, score DESC);

CREATE TABLE IF NOT EXISTS semantic_candidate_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id INTEGER NOT NULL UNIQUE REFERENCES semantic_candidates(id) ON DELETE CASCADE,
    decision TEXT NOT NULL CHECK(decision IN ('alias','related','distinct','ignore')),
    reason TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS field_relations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace TEXT NOT NULL DEFAULT 'global',
    left_field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    right_field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
    relation TEXT NOT NULL CHECK(relation IN ('related_to')),
    reason TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evaluator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(left_field_id, right_field_id, relation),
    CHECK(left_field_id <> right_field_id)
);

CREATE INDEX IF NOT EXISTS idx_field_relations_left ON field_relations(left_field_id);
CREATE INDEX IF NOT EXISTS idx_field_relations_right ON field_relations(right_field_id);
"""


def _column_names(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}


def _add_column_if_missing(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    if column not in _column_names(conn, table):
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def _migrate_governance_schema(conn: sqlite3.Connection) -> None:
    _add_column_if_missing(conn, "fields", "namespace", "namespace TEXT NOT NULL DEFAULT 'global'")
    _add_column_if_missing(conn, "fields", "normalized_key", "normalized_key TEXT")
    _add_column_if_missing(
        conn,
        "field_proposals",
        "namespace",
        "namespace TEXT NOT NULL DEFAULT 'global'",
    )

    rows = conn.execute("SELECT id,key FROM fields WHERE normalized_key IS NULL OR normalized_key='' ").fetchall()
    for row in rows:
        try:
            normalized = normalize_field_key(row["key"])
        except ValueError:
            normalized = f"legacy_{row['id'][:16]}"
        conn.execute(
            "UPDATE fields SET normalized_key=? WHERE id=?",
            (normalized, row["id"]),
        )

    conn.executescript(GOVERNANCE_SCHEMA)

    fields = conn.execute(
        """
        SELECT id,label,value_type,description,created_at
        FROM fields
        WHERE NOT EXISTS (
            SELECT 1 FROM field_versions fv WHERE fv.field_id=fields.id
        )
        """
    ).fetchall()
    for field in fields:
        conn.execute(
            """
            INSERT INTO field_versions(
                field_id,version,label,value_type,description,reason,evaluator,created_at
            ) VALUES(?,1,?,?,?,?,?,?)
            """,
            (
                field["id"],
                field["label"],
                field["value_type"],
                field["description"],
                "v0.2A migration snapshot",
                "system:migration",
                field["created_at"],
            ),
        )


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            conn.executescript(SCHEMA)
            _migrate_governance_schema(conn)
            conn.executescript(SEMANTIC_SCHEMA)

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        return conn

    def scalar(self, sql: str, params: Iterable[Any] = ()) -> Any:
        with self.connect() as conn:
            row = conn.execute(sql, tuple(params)).fetchone()
            return None if row is None else row[0]
