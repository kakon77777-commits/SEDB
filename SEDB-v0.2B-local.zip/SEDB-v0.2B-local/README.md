# SEDB v0.2B — AI-Native Unbounded Dynamic Field Database

**Semantic Evolution Database / Unbounded Dynamic Field Layer / Semantic Candidate & Dedup Kernel**

SEDB is a local-first experimental database for AI-native research, classification, curation, and record keeping where the logical field space can continue to expand without forcing every record to materialize every field.

The original invariant remains:

$$
\boxed{\text{Add Field}\not\Rightarrow\text{Fill Field}}
$$

v0.2A added:

$$
\boxed{\text{Unbounded Field Growth}\neq\text{Ungoverned Canonical Growth}}
$$

v0.2B adds:

$$
\boxed{\text{Similarity Candidate}\neq\text{Canonical Mutation}}
$$

Similarity can trigger review, but cannot automatically merge, alias, or rewrite a canonical field.

## v0.2B highlights

- everything from v0.2A: sparse cells, field registry, lifecycle, proposal decisions, aliases, immutable definition versions, merge/split lineage, Task Views, CSV/JSONL exchange, local API and browser UI;
- deterministic local field-similarity scoring;
- explainable score signals for key, label, description, value type, namespace, and type penalty;
- proposal top-k candidate ranking;
- default namespace isolation;
- bounded candidate generation;
- auditable `alias / related / distinct / ignore` review;
- alias review only for pending proposals;
- canonical-to-canonical alias review rejected; explicit merge governance remains required;
- canonical `related_to` relation edges;
- sorted-neighborhood + rare-token registry scan;
- no embedding, LLM, network call, or runtime third-party dependency.

## Similarity score

$$
S(a,b)=0.45S_{key}+0.30S_{label}+0.10S_{description}+0.10S_{type}+0.05S_{namespace}.
$$

A value-type conflict applies a final multiplier of $0.60$.

The score is a deterministic candidate heuristic, not a claim that two fields are semantically identical.

## Bounded scan

The canonical registry scan uses a sorted lexical neighborhood plus rare-token blocking. Each source field contributes at most `max_neighbors` candidates before scoring and reverse pairs are deduplicated.

For a configured neighborhood cap $k$:

$$
\text{Candidate comparisons}\lesssim O(|F|k)
$$

instead of naively materializing all:

$$
\binom{|F|}{2}
$$

pairs.

## Requirements

- Python 3.11+;
- SQLite included with Python;
- no runtime third-party dependencies;
- `pytest` only for tests.

## Windows PowerShell quick start

```powershell
cd SEDB-v0.2B-local
python -m pip install -e .
sedb demo --db .\sedb-demo.sqlite --fields 10000
sedb serve --db .\sedb-demo.sqlite --host 127.0.0.1 --port 8765
```

Open:

```text
http://127.0.0.1:8765
```

## Python semantic-candidate example

```python
from sedb.db import Database
from sedb.fields import FieldService
from sedb.semantic import SemanticDedupService


db = Database("research.sqlite")
fields = FieldService(db)
semantic = SemanticDedupService(db)

canonical = fields.create_field(
    key="author_country",
    label="Author country",
)
proposal = fields.create_proposal(
    key="country_of_author",
    label="Country of author",
    reason="Imported vocabulary",
)

candidates = semantic.score_proposal(proposal["id"], top_k=5)
review = semantic.review_candidate(
    candidates[0]["id"],
    "alias",
    reason="Reviewed as the same semantic dimension",
    evaluator="reviewer:local",
)
```

The review writes the proposed key directly as an alias of the canonical field. It does not create an alias chain and does not create a second canonical field.

## Important local API routes

```text
POST   /api/proposals/{id}/candidates
GET    /api/proposals/{id}/candidates
GET    /api/candidates
POST   /api/candidates/{id}/review
GET    /api/candidates/{id}/review
POST   /api/governance/similarity/scan
GET    /api/fields/{id}/relations
```

All v0.2A routes remain available.

## Validation

```bash
PYTHONPATH=src pytest -q
python -m compileall -q src examples
node --check src/sedb/web/app.js
```

A 10,000-field bounded-scan demo is available through:

```bash
PYTHONPATH=src python examples/semantic_scan_demo.py --db demo/sedb-semantic-scan-10k-v0.2b.sqlite --fields 10000
```

The reported runtime is only evidence for that concrete local run and must not be generalized to all machines or workloads.

The packaged validation run recorded:

```text
fields: 10000
naive unordered all-pairs: 49,995,000
bounded candidate upper bound (k=6): 60,000
persisted candidates at threshold 0.95: 2
expected duplicate pairs found: 2/2
elapsed on this release environment: 7.983901 seconds
```


## Project status

This artifact is the **local v0.2B checkpoint**. GitHub remains intentionally unchanged during local-first development.

$$
\boxed{\text{Local Development}\rightarrow\text{Validation}\rightarrow\text{Stable Snapshot}\rightarrow\text{Selective GitHub Sync}}
$$

## Licensing status

No public software license is selected by this local artifact. Do not infer an open-source license from the source bundle or public repository.
