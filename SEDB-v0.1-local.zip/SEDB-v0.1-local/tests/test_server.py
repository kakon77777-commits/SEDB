import json
import threading
from contextlib import contextmanager
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from sedb.server import create_server


@contextmanager
def running_server(tmp_path):
    server = create_server(tmp_path / "server.sqlite", host="127.0.0.1", port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address
    try:
        yield f"http://{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def request_json(base, method, path, payload=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = Request(
        base + path,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"} if data is not None else {},
    )
    try:
        with urlopen(req, timeout=3) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def test_health_and_static_index(tmp_path):
    with running_server(tmp_path) as base:
        status, health = request_json(base, "GET", "/api/health")
        with urlopen(base + "/", timeout=3) as response:
            html = response.read().decode("utf-8")

    assert status == 200
    assert health == {"ok": True, "version": "0.1.0"}
    assert "SEDB" in html
    assert "Unbounded Dynamic Field" in html


def test_field_entity_and_sparse_cell_api(tmp_path):
    with running_server(tmp_path) as base:
        field_status, field = request_json(
            base,
            "POST",
            "/api/fields",
            {"key": "year", "label": "Year", "value_type": "integer"},
        )
        entity_status, entity = request_json(
            base, "POST", "/api/entities", {"label": "Paper 1", "kind": "paper"}
        )
        cell_status, cell = request_json(
            base,
            "PUT",
            f"/api/entities/{entity['id']}/cells/year",
            {"value": 2026, "source": "test"},
        )
        loaded_status, loaded = request_json(base, "GET", f"/api/entities/{entity['id']}")
        stats_status, stats = request_json(base, "GET", "/api/stats")

    assert (field_status, entity_status, cell_status, loaded_status, stats_status) == (200, 200, 200, 200, 200)
    assert field["key"] == "year"
    assert cell["value"] == 2026
    assert loaded["values"] == {"year": 2026}
    assert stats["fields"] == 1 and stats["entities"] == 1 and stats["cells"] == 1


def test_converge_api_requires_reason_and_records_evaluation(tmp_path):
    with running_server(tmp_path) as base:
        _, field = request_json(base, "POST", "/api/fields", {"key": "country", "label": "Country"})
        bad_status, bad = request_json(
            base,
            "POST",
            f"/api/fields/{field['id']}/transition",
            {"to_status": "converged", "reason": ""},
        )
        good_status, converged = request_json(
            base,
            "POST",
            f"/api/fields/{field['id']}/transition",
            {
                "to_status": "converged",
                "reason": "Low marginal utility.",
                "metrics": {"utility": 0.05},
                "evaluator": "api:test",
            },
        )
        eval_status, evaluations = request_json(
            base, "GET", f"/api/fields/{field['id']}/evaluations"
        )

    assert bad_status == 400
    assert "reason" in bad["error"]
    assert good_status == 200 and converged["status"] == "converged"
    assert eval_status == 200
    assert evaluations[0]["metrics"] == {"utility": 0.05}


def test_proposal_and_task_view_api(tmp_path):
    with running_server(tmp_path) as base:
        request_json(base, "POST", "/api/fields", {"key": "year", "label": "Year"})
        request_json(base, "POST", "/api/fields", {"key": "verified", "label": "Verified"})
        _, entity = request_json(base, "POST", "/api/entities", {"label": "Paper"})
        request_json(base, "PUT", f"/api/entities/{entity['id']}/cells/year", {"value": 2026})
        proposal_status, proposal = request_json(
            base,
            "POST",
            "/api/proposals",
            {
                "key": "ai_evidence",
                "label": "AI evidence",
                "reason": "Potential discriminator",
                "proposed_by": "agent:test",
            },
        )
        view_status, view = request_json(
            base,
            "POST",
            "/api/views",
            {"name": "Audit", "field_keys": ["year", "verified"]},
        )
        matrix_status, matrix = request_json(base, "GET", f"/api/views/{view['id']}?field_limit=1")

    assert proposal_status == 200 and proposal["status"] == "pending"
    assert view_status == 200
    assert matrix_status == 200
    assert matrix["total_fields"] == 2
    assert [f["key"] for f in matrix["fields"]] == ["year"]
    assert matrix["rows"][0]["values"] == {"year": 2026}


def test_delete_cell_api_restores_blank(tmp_path):
    with running_server(tmp_path) as base:
        request_json(base, "POST", "/api/fields", {"key": "note", "label": "Note"})
        _, entity = request_json(base, "POST", "/api/entities", {"label": "Paper"})
        request_json(base, "PUT", f"/api/entities/{entity['id']}/cells/note", {"value": "x"})
        deleted_status, deleted = request_json(
            base, "DELETE", f"/api/entities/{entity['id']}/cells/note"
        )
        _, loaded = request_json(base, "GET", f"/api/entities/{entity['id']}")

    assert deleted_status == 200 and deleted == {"deleted": True}
    assert loaded["values"] == {}
