# SEDB v0.1 — AI-Native Unbounded Dynamic Field Database

**Semantic Evolution Database / Unbounded Dynamic Field Layer**

SEDB v0.1 is a local-first experimental database for AI-native research, classification, curation, and record keeping where the logical field space may grow from hundreds to thousands or tens of thousands of fields.

The central rule is:

$$
\boxed{\text{Add Field}\not\Rightarrow\text{Fill Field}}
$$

A globally registered field may be blank for almost every record. Blank is a valid structural state, not an error and not a forced placeholder.

## Why this exists

Traditional fixed-schema tables work well when the set of columns is known and relatively stable. AI research workflows often discover new distinctions while working: a new provenance dimension, a new classification criterion, a new failure reason, a new uncertainty measure, or a new search facet.

SEDB separates logical width from physical density.

Let $E$ be records, $F$ an open-ended field registry, and $D_f$ the value domain of field $f$:

$$
V:E\times F\rightarrow D_f\cup\{\varnothing\}.
$$

Only present values are physically stored:

$$
C=\{(e,f,v)\mid V(e,f)\neq\varnothing\}.
$$

This means a database can expose:

$$
|F|=10^2,10^3,10^4,10^5
$$

without materializing every possible record-field pair.

## v0.1 features

- dynamic field registry without `ALTER TABLE ADD COLUMN`;
- sparse JSON-valued cells;
- true blank-by-absence semantics;
- field lifecycle: `proposed`, `active`, `converged`, `merged`, `split`, `deprecated`;
- mandatory reason assessment when a field converges;
- reason-governed reactivation of converged fields;
- lifecycle events and evaluation history;
- AI/user field proposals separated from the active registry;
- task views as projections over the same sparse database;
- bounded field-window matrix rendering;
- field/entity/cell search;
- CSV and JSONL import/export services;
- local JSON HTTP API;
- dependency-free browser UI;
- automated 10,000-logical-field validation.

## Storage model

SQLite uses normalized sparse structures:

```text
entities
fields
cells
field_events
field_evaluations
field_proposals
task_views
task_view_fields
```

A field can exist while `cells` contains zero rows for that field. No table migration is needed when a field is discovered.

## Convergence is governance, not deletion

The normal lifecycle is:

$$
\text{Proposed}\rightarrow\text{Active}\rightarrow\text{Converged}.
$$

A converged field can later return:

$$
\text{Converged}\rightarrow\text{Active}.
$$

SEDB rejects convergence without a reason. A convergence/reactivation evaluation can store:

- reason;
- evidence;
- metrics;
- evaluator;
- reversibility;
- timestamp.

`Converged` means the system does not currently need to actively expand or prioritize the field. It does **not** mean the historical field is deleted.

## Task views

A task view selects a local effective support:

$$
F_Q\subseteq F.
$$

For example, the global registry may contain 10,000 fields while a particular research audit renders only 12. The browser matrix retrieves and renders a field window instead of creating thousands of DOM columns.

## Requirements

- Python 3.11+; validated with Python 3.13.
- SQLite included with Python.
- No runtime third-party dependencies.
- `pytest` is needed only for the test suite.

## Quick start — Windows PowerShell

```powershell
cd SEDB-local
python -m pip install -e .
sedb demo --db .\sedb-demo.sqlite --fields 10000
sedb serve --db .\sedb-demo.sqlite --host 127.0.0.1 --port 8765
```

Open `http://127.0.0.1:8765` in a browser.

If editable installation is not desired:

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m sedb.cli demo --db .\sedb-demo.sqlite --fields 10000
python -m sedb.cli serve --db .\sedb-demo.sqlite
```

## Quick start — Linux / macOS

```bash
cd SEDB-local
python -m pip install -e .
sedb demo --db ./sedb-demo.sqlite --fields 10000
sedb serve --db ./sedb-demo.sqlite --host 127.0.0.1 --port 8765
```

Without installation:

```bash
PYTHONPATH=src python -m sedb.cli demo --db ./sedb-demo.sqlite --fields 10000
PYTHONPATH=src python -m sedb.cli serve --db ./sedb-demo.sqlite
```

## CLI

Initialize an empty database:

```bash
sedb init --db sedb.sqlite
```

Build the 10,000-field sparse demonstration:

```bash
sedb demo --db sedb-demo.sqlite --fields 10000
```

Inspect statistics:

```bash
sedb stats --db sedb-demo.sqlite
```

Start the UI:

```bash
sedb serve --db sedb-demo.sqlite --port 8765
```

## Python API example

```python
from sedb.db import Database
from sedb.fields import FieldService
from sedb.entities import EntityService


db = Database("research.sqlite")
fields = FieldService(db)
entities = EntityService(db)

fields.create_field(key="verified", label="Verified", value_type="boolean")
record = entities.create_entity(label="Paper 001", kind="paper")
entities.set_cell(record["id"], "verified", False, source="manual")
```

Registering another 10,000 fields does not fill this record. Missing cells remain absent.

## CSV / JSONL exchange

The exchange layer is available through `ExchangeService`:

```python
from sedb.exchange import ExchangeService

exchange = ExchangeService(db)
exchange.export_jsonl("records.jsonl")
exchange.export_csv("records.csv")
```

CSV uses an empty cell for absence. Present values are JSON-encoded so numbers, booleans, arrays, objects, and explicit JSON `null` can be distinguished from blank.

## Local API

Important routes include:

```text
GET    /api/health
GET    /api/stats
GET    /api/fields
POST   /api/fields
POST   /api/fields/{id}/transition
GET    /api/fields/{id}/evaluations
GET    /api/proposals
POST   /api/proposals
GET    /api/entities
POST   /api/entities
GET    /api/entities/{id}
PUT    /api/entities/{id}/cells/{field_key}
DELETE /api/entities/{id}/cells/{field_key}
GET    /api/search?q=...
GET    /api/views
POST   /api/views
GET    /api/views/{id}?field_offset=0&field_limit=25
```

To make a cell blank, use `DELETE`; do not write a fake placeholder.

## Test

```bash
PYTHONPATH=src pytest -q
python -m compileall -q src examples
```

The suite includes a real registry containing at least 10,000 logical fields and verifies that sparse cell count remains small.

## Project status

This artifact is the **local v0.1 checkpoint**. The implementation is intentionally developed and validated locally before any later stable snapshot is selected for GitHub.

Current flow:

$$
\boxed{
\text{Local Development}
\rightarrow
\text{Validation}
\rightarrow
\text{Stable Snapshot}
\rightarrow
\text{Selective GitHub Sync}
}
$$

The public repository should not be interpreted as containing the latest local implementation until a snapshot is explicitly synchronized.

## Licensing status

No public software license is selected by this local v0.1 artifact. Do not infer an open-source license from the existence of the source bundle or public repository. A license can be selected separately before a public code release.

## Design documents

- `docs/superpowers/specs/2026-08-20-sedb-unbounded-field-v0.1-design.md`
- `docs/superpowers/plans/2026-08-20-sedb-unbounded-field-v0.1.md`
- `docs/RELEASE_NOTES_v0.1.md`
