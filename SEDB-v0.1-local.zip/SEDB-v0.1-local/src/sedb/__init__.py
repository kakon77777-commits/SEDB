"""SEDB local-first unbounded dynamic field database."""

__version__ = "0.1.0"
