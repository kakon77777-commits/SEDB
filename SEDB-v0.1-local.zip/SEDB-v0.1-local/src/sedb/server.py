from __future__ import annotations

import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from . import __version__
from .db import Database
from .entities import EntityService
from .fields import FieldService
from .views import ViewService


_WEB_DIR = Path(__file__).with_name("web")


def create_server(db_path: str | Path, host: str = "127.0.0.1", port: int = 8765) -> ThreadingHTTPServer:
    db = Database(db_path)
    fields = FieldService(db)
    entities = EntityService(db)
    views = ViewService(db)

    class Handler(BaseHTTPRequestHandler):
        server_version = "SEDB/0.1"

        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, payload: Any, status: int = 200) -> None:
            data = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _read_json(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length == 0:
                return {}
            raw = self.rfile.read(length)
            value = json.loads(raw.decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError("JSON request body must be an object")
            return value

        def _serve_static(self, request_path: str) -> bool:
            mapping = {
                "/": "index.html",
                "/index.html": "index.html",
                "/app.js": "app.js",
                "/style.css": "style.css",
            }
            filename = mapping.get(request_path)
            if filename is None:
                return False
            path = _WEB_DIR / filename
            data = path.read_bytes()
            content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            if filename.endswith((".html", ".js", ".css")):
                content_type += "; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return True

        def _route(self) -> None:
            parsed = urlparse(self.path)
            path = unquote(parsed.path)
            query = parse_qs(parsed.query)
            if self.command == "GET" and not path.startswith("/api/"):
                if self._serve_static(path):
                    return
                self._send_json({"error": "not found"}, 404)
                return

            segments = [segment for segment in path.split("/") if segment]
            try:
                if self.command == "GET" and path == "/api/health":
                    self._send_json({"ok": True, "version": __version__})
                    return
                if self.command == "GET" and path == "/api/stats":
                    self._send_json(views.stats())
                    return
                if self.command == "GET" and path == "/api/fields":
                    self._send_json(
                        fields.list_fields(
                            search=query.get("search", [""])[0],
                            status=query.get("status", [""])[0],
                            limit=int(query.get("limit", ["100"])[0]),
                            offset=int(query.get("offset", ["0"])[0]),
                        )
                    )
                    return
                if self.command == "POST" and path == "/api/fields":
                    body = self._read_json()
                    self._send_json(
                        fields.create_field(
                            key=str(body.get("key", "")),
                            label=str(body.get("label", "")),
                            value_type=str(body.get("value_type", "text")),
                            description=str(body.get("description", "")),
                            status=str(body.get("status", "active")),
                        )
                    )
                    return
                if len(segments) == 4 and segments[:2] == ["api", "fields"] and segments[3] == "transition" and self.command == "POST":
                    body = self._read_json()
                    self._send_json(
                        fields.transition(
                            segments[2],
                            str(body.get("to_status", "")),
                            reason=str(body.get("reason", "")),
                            evidence=body.get("evidence") if isinstance(body.get("evidence"), dict) else {},
                            metrics=body.get("metrics") if isinstance(body.get("metrics"), dict) else {},
                            evaluator=str(body.get("evaluator", "")),
                            reversible=bool(body.get("reversible", True)),
                        )
                    )
                    return
                if len(segments) == 4 and segments[:2] == ["api", "fields"] and segments[3] == "evaluations" and self.command == "GET":
                    self._send_json(fields.list_evaluations(segments[2]))
                    return
                if self.command == "GET" and path == "/api/proposals":
                    self._send_json(
                        fields.list_proposals(
                            limit=int(query.get("limit", ["100"])[0]),
                            offset=int(query.get("offset", ["0"])[0]),
                        )
                    )
                    return
                if self.command == "POST" and path == "/api/proposals":
                    body = self._read_json()
                    self._send_json(
                        fields.create_proposal(
                            key=str(body.get("key", "")),
                            label=str(body.get("label", "")),
                            reason=str(body.get("reason", "")),
                            value_type=str(body.get("value_type", "text")),
                            description=str(body.get("description", "")),
                            proposed_by=str(body.get("proposed_by", "")),
                        )
                    )
                    return
                if self.command == "GET" and path == "/api/entities":
                    self._send_json(
                        entities.list_entities(
                            limit=int(query.get("limit", ["1000"])[0]),
                            offset=int(query.get("offset", ["0"])[0]),
                        )
                    )
                    return
                if self.command == "POST" and path == "/api/entities":
                    body = self._read_json()
                    self._send_json(
                        entities.create_entity(
                            label=str(body.get("label", "")),
                            kind=str(body.get("kind", "record")),
                            entity_id=str(body.get("id", "")).strip() or None,
                        )
                    )
                    return
                if len(segments) == 3 and segments[:2] == ["api", "entities"] and self.command == "GET":
                    self._send_json(entities.get_entity(segments[2]))
                    return
                if len(segments) == 5 and segments[:2] == ["api", "entities"] and segments[3] == "cells":
                    entity_id, field_key = segments[2], segments[4]
                    if self.command == "PUT":
                        body = self._read_json()
                        if "value" not in body:
                            raise ValueError("cell value is required; use DELETE to make a cell blank")
                        self._send_json(
                            entities.set_cell(
                                entity_id,
                                field_key,
                                body["value"],
                                source=str(body.get("source", "")),
                                confidence=body.get("confidence"),
                            )
                        )
                        return
                    if self.command == "DELETE":
                        self._send_json({"deleted": entities.delete_cell(entity_id, field_key)})
                        return
                if self.command == "GET" and path == "/api/search":
                    self._send_json(
                        views.search(
                            query.get("q", [""])[0],
                            limit=int(query.get("limit", ["100"])[0]),
                        )
                    )
                    return
                if self.command == "GET" and path == "/api/views":
                    self._send_json(views.list_views())
                    return
                if self.command == "POST" and path == "/api/views":
                    body = self._read_json()
                    field_keys = body.get("field_keys")
                    if not isinstance(field_keys, list):
                        raise ValueError("field_keys must be an array")
                    self._send_json(
                        views.create_view(
                            str(body.get("name", "")),
                            [str(key) for key in field_keys],
                            query_text=str(body.get("query_text", "")),
                        )
                    )
                    return
                if len(segments) == 3 and segments[:2] == ["api", "views"] and self.command == "GET":
                    self._send_json(
                        views.get_view_matrix(
                            segments[2],
                            field_offset=int(query.get("field_offset", ["0"])[0]),
                            field_limit=int(query.get("field_limit", ["25"])[0]),
                            entity_offset=int(query.get("entity_offset", ["0"])[0]),
                            entity_limit=int(query.get("entity_limit", ["1000"])[0]),
                        )
                    )
                    return
                self._send_json({"error": "not found"}, 404)
            except KeyError as exc:
                self._send_json({"error": str(exc).strip("'")}, 404)
            except (ValueError, json.JSONDecodeError) as exc:
                self._send_json({"error": str(exc)}, 400)
            except Exception as exc:
                self._send_json({"error": f"internal error: {exc}"}, 500)

        def do_GET(self) -> None:
            self._route()

        def do_POST(self) -> None:
            self._route()

        def do_PUT(self) -> None:
            self._route()

        def do_DELETE(self) -> None:
            self._route()

    return ThreadingHTTPServer((host, port), Handler)
