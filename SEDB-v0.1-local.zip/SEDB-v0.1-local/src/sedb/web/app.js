const state = { viewId: null, fieldOffset: 0, fieldLimit: 12 };

async function api(path, options = {}) {
  const config = { ...options, headers: { ...(options.headers || {}) } };
  if (config.body && typeof config.body !== 'string') {
    config.headers['Content-Type'] = 'application/json';
    config.body = JSON.stringify(config.body);
  }
  const response = await fetch(path, config);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

function toast(message, error = false) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.className = error ? 'show error' : 'show';
  setTimeout(() => el.className = '', 2600);
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

async function loadStats() {
  const s = await api('/api/stats');
  const items = [
    ['Fields', s.fields], ['Active', s.active_fields], ['Converged', s.converged_fields],
    ['Entities', s.entities], ['Sparse Cells', s.cells], ['Views', s.views],
    ['Logical Capacity', s.logical_capacity], ['Density', `${(s.density * 100).toFixed(5)}%`]
  ];
  document.getElementById('stats').innerHTML = items.map(([k,v]) => `<div><strong>${esc(v)}</strong><span>${esc(k)}</span></div>`).join('');
}

async function loadFields() {
  const q = document.getElementById('fieldSearch').value.trim();
  const rows = await api(`/api/fields?limit=200&search=${encodeURIComponent(q)}`);
  const list = document.getElementById('fieldList');
  list.innerHTML = rows.map(f => {
    const action = f.status === 'active' ? 'converge' : (f.status === 'converged' ? 'reactivate' : '');
    return `<div class="item">
      <div><code>${esc(f.key)}</code><strong>${esc(f.label)}</strong><small>${esc(f.value_type)} · ${esc(f.status)}</small></div>
      ${action ? `<button data-field="${esc(f.id)}" data-action="${action}">${action === 'converge' ? '收斂' : '重新啟用'}</button>` : ''}
    </div>`;
  }).join('') || '<div class="empty">沒有欄位</div>';
  list.querySelectorAll('button[data-field]').forEach(button => button.addEventListener('click', async () => {
    const action = button.dataset.action;
    const reason = prompt(action === 'converge' ? '收斂原因（必填）' : '重新啟用原因（必填）');
    if (!reason) return;
    const to_status = action === 'converge' ? 'converged' : 'active';
    try {
      await api(`/api/fields/${button.dataset.field}/transition`, {method:'POST', body:{to_status, reason, evaluator:'browser:user'}});
      toast('欄位狀態已更新');
      await refreshAll();
    } catch (e) { toast(e.message, true); }
  }));
}

async function loadEntities() {
  const rows = await api('/api/entities?limit=500');
  document.getElementById('entityList').innerHTML = rows.map(e =>
    `<div class="item"><div><strong>${esc(e.label)}</strong><small>${esc(e.kind)} · ${esc(e.id)}</small></div></div>`
  ).join('') || '<div class="empty">沒有 Entity</div>';
}

async function loadViews() {
  const rows = await api('/api/views');
  const select = document.getElementById('viewSelect');
  const previous = state.viewId;
  select.innerHTML = rows.map(v => `<option value="${esc(v.id)}">${esc(v.name)} (${v.field_count})</option>`).join('');
  if (rows.length) {
    state.viewId = rows.some(v => v.id === previous) ? previous : rows[0].id;
    select.value = state.viewId;
  } else {
    state.viewId = null;
  }
}

function displayValue(value) {
  if (typeof value === 'string') return value;
  return JSON.stringify(value);
}

async function loadMatrix() {
  const table = document.getElementById('matrix');
  if (!state.viewId) {
    table.innerHTML = '<tr><td class="empty">先建立 Task View</td></tr>';
    document.getElementById('windowInfo').textContent = '';
    return;
  }
  const m = await api(`/api/views/${state.viewId}?field_offset=${state.fieldOffset}&field_limit=${state.fieldLimit}`);
  const head = `<tr><th>Entity</th>${m.fields.map(f => `<th title="${esc(f.label)}">${esc(f.key)}</th>`).join('')}</tr>`;
  const body = m.rows.map(row => `<tr><th>${esc(row.label)}</th>${m.fields.map(f => {
    const present = Object.prototype.hasOwnProperty.call(row.values, f.key);
    const text = present ? displayValue(row.values[f.key]) : '';
    return `<td><button class="cell ${present ? 'present' : 'blank'}" data-entity="${esc(row.id)}" data-field="${esc(f.key)}" data-present="${present ? '1' : '0'}">${present ? esc(text) : '∅'}</button></td>`;
  }).join('')}</tr>`).join('');
  table.innerHTML = head + body;
  document.getElementById('windowInfo').textContent = `${m.field_offset + 1}–${Math.min(m.total_fields, m.field_offset + m.fields.length)} / ${m.total_fields}`;
  table.querySelectorAll('button.cell').forEach(button => button.addEventListener('click', async () => {
    const present = button.dataset.present === '1';
    const promptText = present ? '輸入 JSON 值；留空並確認會刪除此 cell' : '輸入 JSON 值（字串請加雙引號）';
    const raw = prompt(promptText, present ? button.textContent : '');
    if (raw === null) return;
    try {
      if (raw === '' && present) {
        await api(`/api/entities/${button.dataset.entity}/cells/${encodeURIComponent(button.dataset.field)}`, {method:'DELETE'});
      } else {
        let value;
        try { value = JSON.parse(raw); } catch { value = raw; }
        await api(`/api/entities/${button.dataset.entity}/cells/${encodeURIComponent(button.dataset.field)}`, {method:'PUT', body:{value, source:'browser:user'}});
      }
      await loadMatrix(); await loadStats();
    } catch (e) { toast(e.message, true); }
  }));
}

async function refreshAll() {
  try {
    await Promise.all([loadStats(), loadFields(), loadEntities()]);
    await loadViews();
    await loadMatrix();
  } catch (e) { toast(e.message, true); }
}

document.getElementById('fieldForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = new FormData(event.currentTarget);
  try {
    await api('/api/fields', {method:'POST', body:Object.fromEntries(form.entries())});
    event.currentTarget.reset(); toast('欄位已新增'); await refreshAll();
  } catch (e) { toast(e.message, true); }
});

document.getElementById('entityForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = new FormData(event.currentTarget);
  try {
    await api('/api/entities', {method:'POST', body:Object.fromEntries(form.entries())});
    event.currentTarget.reset(); toast('Entity 已新增'); await refreshAll();
  } catch (e) { toast(e.message, true); }
});

document.getElementById('viewForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = new FormData(event.currentTarget);
  const field_keys = String(form.get('field_keys') || '').split(',').map(x => x.trim()).filter(Boolean);
  try {
    const view = await api('/api/views', {method:'POST', body:{name:form.get('name'), field_keys}});
    state.viewId = view.id; state.fieldOffset = 0; toast('Task View 已建立'); await loadViews(); await loadMatrix(); await loadStats();
  } catch (e) { toast(e.message, true); }
});

document.getElementById('fieldSearchBtn').addEventListener('click', loadFields);
document.getElementById('fieldSearch').addEventListener('keydown', e => { if (e.key === 'Enter') loadFields(); });
document.getElementById('refreshAll').addEventListener('click', refreshAll);
document.getElementById('loadView').addEventListener('click', () => { state.viewId = document.getElementById('viewSelect').value; state.fieldOffset = 0; loadMatrix(); });
document.getElementById('viewSelect').addEventListener('change', e => { state.viewId = e.target.value; state.fieldOffset = 0; });
document.getElementById('prevFields').addEventListener('click', () => { state.fieldOffset = Math.max(0, state.fieldOffset - state.fieldLimit); loadMatrix(); });
document.getElementById('nextFields').addEventListener('click', () => { state.fieldOffset += state.fieldLimit; loadMatrix(); });
document.getElementById('globalSearchBtn').addEventListener('click', async () => {
  try {
    const q = document.getElementById('globalSearch').value.trim();
    const data = await api(`/api/search?q=${encodeURIComponent(q)}`);
    document.getElementById('searchResults').textContent = JSON.stringify(data, null, 2);
  } catch (e) { toast(e.message, true); }
});

refreshAll();
