# 10,000-field demonstration database

`sedb-demo-10k.sqlite` is generated from the v0.1 CLI with 10,000 logical fields, 3 entities, and only a small sparse set of present cells.

Run:

```bash
PYTHONPATH=src python -m sedb.cli stats --db demo/sedb-demo-10k.sqlite
PYTHONPATH=src python -m sedb.cli serve --db demo/sedb-demo-10k.sqlite
```
