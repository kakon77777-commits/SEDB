# SEDB Demo Databases

The `demo/` directory contains local validation fixtures from successive SEDB checkpoints.

## v0.3C

- `sedb-agent-governance-v0.3c.sqlite` — governed Agent fixture covering deterministic discovery, external suggestions, a denied `set_cell` intent, and budget exhaustion while preserving canonical field/cell counts.
- `sedb-agent-observation-v0.3c.sqlite` — 2,000-record × 20-field provider-free deterministic observation benchmark.
- `agent-stats-v0.3c.json` — exact captured outputs from both v0.3C fixtures.
- `DEMO_SHA256_v0.3C.txt` — SHA-256 for the two packaged v0.3C SQLite fixtures.

## v0.3B

- `sedb-family-governance-v0.3b.sqlite` — reviewed duplicate/related/split/reject family-governance fixture.
- `sedb-family-10k-v0.3b.sqlite` — bounded 10,000-field family-scan fixture.
- `family-stats-v0.3b.json` — exact captured v0.3B family benchmark output.
- `DEMO_SHA256_v0.3B.txt` — SHA-256 for the two packaged v0.3B SQLite fixtures.

## v0.3A

- `sedb-utility-governance-v0.3a.sqlite` — small field-utility governance fixture containing all utility-v1 recommendation categories and an explicit apply trail.
- `sedb-utility-10k-v0.3a.sqlite` — fresh 10,000-field registry with 10,000 immutable utility-v1 assessments.
- `utility-stats-v0.3a.json` — exact output captured from the packaged v0.3A utility demo/benchmark run.
- `DEMO_SHA256_v0.3A.txt` — SHA-256 for the two packaged v0.3A SQLite fixtures.

## v0.2B retained fixtures

- `sedb-demo-10k-v0.2b.sqlite` — sparse 10K field base demo.
- `sedb-semantic-scan-10k-v0.2b.sqlite` — bounded semantic-candidate scan fixture.
- `sedb-governance-v0.2b.sqlite` — canonical field governance and semantic review fixture.

Older fixtures are retained as migration/regression evidence; v0.3A does not rewrite them in place.
