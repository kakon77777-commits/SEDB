"""SEDB local-first unbounded dynamic field database."""

__version__ = "0.3.0a1"
