# SEDB Demo Databases

The `demo/` directory contains local validation fixtures from successive SEDB checkpoints.

## v0.3A

- `sedb-utility-governance-v0.3a.sqlite` — small field-utility governance fixture containing all utility-v1 recommendation categories and an explicit apply trail.
- `sedb-utility-10k-v0.3a.sqlite` — fresh 10,000-field registry with 10,000 immutable utility-v1 assessments.
- `utility-stats-v0.3a.json` — exact output captured from the packaged v0.3A utility demo/benchmark run.
- `DEMO_SHA256_v0.3A.txt` — SHA-256 for the two packaged v0.3A SQLite fixtures.

## v0.2B retained fixtures

- `sedb-demo-10k-v0.2b.sqlite` — sparse 10K field base demo.
- `sedb-semantic-scan-10k-v0.2b.sqlite` — bounded semantic-candidate scan fixture.
- `sedb-governance-v0.2b.sqlite` — canonical field governance and semantic review fixture.

Older fixtures are retained as migration/regression evidence; v0.3A does not rewrite them in place.
